CREATE TABLE t_summary_for_user (
site_code CHAR(2)
,user_id VARCHAR(80)
,period_code CHAR(2)
,user_hk_count INT
,user_hk_days_count INT
,user_hk_price BIGINT
,user_hk_guest_count INT
,user_cx_count INT
,user_cx_days_count INT
,user_cx_price BIGINT
,user_cx_guest_count INT
,user_ns_count INT
,user_ns_days_count INT
,user_ns_price BIGINT
,user_ns_guest_count INT
,user_hk_days_guest_count INT
,user_ns_days_guest_count INT
,hk_days_count_per_facility TEXT
,max_checkout_date DATE
,PRIMARY KEY (site_code, user_id, period_code)
); 
