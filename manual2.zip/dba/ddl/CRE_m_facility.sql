CREATE TABLE m_facility (
bb_facility_no INT PRIMARY KEY AUTO_INCREMENT
,facility_name VARCHAR(100) NOT NULL
,post_code1 CHAR(3) NOT NULL
,post_code2 CHAR(4) NOT NULL
,prefecture_code CHAR(2) NOT NULL
,address1 VARCHAR(50) NOT NULL
,address2 VARCHAR(50) NOT NULL
,address3 VARCHAR(50)
,contract_family_name VARCHAR(20) NOT NULL
,contract_given_name VARCHAR(20) NOT NULL
,contract_telephone_number VARCHAR(13) NOT NULL
,contract_fax_number VARCHAR(15)
,contract_mail_address VARCHAR(100) NOT NULL
,rt_facility_no VARCHAR(50)
,rt_bb_flag CHAR(1) NOT NULL
,rt_bb_start_date DATE
,rt_bb_end_date DATE
,jalan_facility_no VARCHAR(50)
,jalan_bb_flag CHAR(1) NOT NULL
,jalan_bb_start_date DATE
,jalan_bb_end_date DATE
,ikyu_facility_no VARCHAR(50)
,ikyu_bb_flag CHAR(1) NOT NULL
,ikyu_bb_start_date DATE
,ikyu_bb_end_date DATE
,his_facility_no VARCHAR(50)
,his_bb_flag CHAR(1) NOT NULL
,his_bb_start_date DATE
,his_bb_end_date DATE
,entry_date DATETIME NOT NULL
,entry_staff_code VARCHAR(8) NOT NULL
,update_date DATETIME
,update_staff_code VARCHAR(8)
); 
