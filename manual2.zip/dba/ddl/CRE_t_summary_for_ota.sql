CREATE TABLE t_summary_for_ota (
site_code CHAR(2)
,period_code CHAR(2)
,site_hk_count INT
,site_hk_days_count INT
,site_hk_price BIGINT
,site_hk_guest_count INT
,site_cx_count INT
,site_cx_days_count INT
,site_cx_price BIGINT
,site_cx_guest_count INT
,site_ns_count INT
,site_ns_days_count INT
,site_ns_price BIGINT
,site_ns_guest_count INT
,site_hk_days_guest_count INT
,site_ns_days_guest_count INT
,PRIMARY KEY (site_code, period_code)
); 
