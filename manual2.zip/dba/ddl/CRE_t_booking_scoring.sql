CREATE TABLE t_booking_scoring (
site_code CHAR(2)
,booking_no VARCHAR(80)
,login_time DATETIME
,booking_time DATETIME NOT NULL
,checkin_date DATE NOT NULL
,checkout_date DATE NOT NULL
,hk_days_count INT NOT NULL
,cx_days_count INT NOT NULL
,ns_days_count INT NOT NULL
,guest_count INT NOT NULL
,child_guest_count INT NOT NULL
,male_guest_count INT NOT NULL
,female_guest_count INT NOT NULL
,checkin_time VARCHAR(5) NOT NULL
,traveltype_code CHAR(2) NOT NULL
,room_count INT NOT NULL
,room_capacity INT
,payment_code CHAR(2) NOT NULL
,hk_total_amount INT NOT NULL
,cx_total_amount INT NOT NULL
,ns_total_amount INT NOT NULL
,coupon_use_code CHAR(2)
,go_to_code CHAR(2)
,user_id VARCHAR(80) NOT NULL
,member_code CHAR(2) NOT NULL
,member_regist_time DATETIME
,domestin_user_code CHAR(2) NOT NULL
,name VARCHAR(50)
,telephone_number VARCHAR(13)
,mailaddress VARCHAR(100)
,age INT
,facility_no VARCHAR(50)
,facility_room_count INT
,facility_prefecture VARCHAR(20)
,facility_type VARCHAR(60)
,checkin_start_time VARCHAR(5)
,checkin_end_time VARCHAR(5)
,checkout_end_time VARCHAR(5)
,entry_date DATETIME NOT NULL
,PRIMARY KEY (site_code, booking_no)
); 

CREATE INDEX idx_checkin_date ON t_booking_scoring (checkin_date);

CREATE INDEX idx_user_id ON t_booking_scoring (user_id);
