CREATE TABLE t_summary_for_facility (
site_code CHAR(2)
,facility_no VARCHAR(50)
,period_code CHAR(2)
,facility_hk_count INT
,facility_hk_days_count INT
,facility_hk_price BIGINT
,facility_hk_guest_count INT
,facility_cx_count INT
,facility_cx_days_count INT
,facility_cx_price BIGINT
,facility_cx_guest_count INT
,facility_ns_count INT
,facility_ns_days_count INT
,facility_ns_price BIGINT
,facility_ns_guest_count INT
,facility_hk_days_guest_count INT
,facility_ns_days_guest_count INT
,PRIMARY KEY (site_code, facility_no, period_code)
); 
