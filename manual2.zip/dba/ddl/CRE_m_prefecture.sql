CREATE TABLE m_prefecture (
prefecture_code CHAR(2) PRIMARY KEY
,prefecture_name VARCHAR(20) NOT NULL
,entry_date DATE NOT NULL
,entry_staff_code VARCHAR(8) NOT NULL
,update_date DATE
,update_staff_code VARCHAR(8)
); 
