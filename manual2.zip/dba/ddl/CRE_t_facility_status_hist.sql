CREATE TABLE t_facility_status_hist (
bb_facility_no VARCHAR(6)
,site_code CHAR(2)
,status_change_code CHAR(2) NOT NULL
,remarks VARCHAR(1000)
,entry_date DATETIME NOT NULL
,entry_staff_code VARCHAR(8) NOT NULL
,PRIMARY KEY (bb_facility_no, site_code)
); 
