CREATE TABLE t_invoice (
bb_facility_no VARCHAR(6)
,invoice_ym VARCHAR(6)
,site_code CHAR(2)
,invoice_target_ym VARCHAR(6) NOT NULL
,ota_facility_no VARCHAR(25) NOT NULL
,booking_count INT NOT NULL
,system_fee INT NOT NULL
,trade_detail VARCHAR(300) NOT NULL
,entry_date DATETIME NOT NULL
,entry_staff_code VARCHAR(8) NOT NULL
,PRIMARY KEY (bb_facility_no, invoice_ym, site_code)
); 
