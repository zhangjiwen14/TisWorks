CREATE TABLE m_system_fee (
site_code CHAR(2)
,booking_count_from INT
,booking_count_to INT
,system_fee INT NOT NULL
,entry_date DATETIME NOT NULL
,entry_staff_code VARCHAR(8) NOT NULL
,PRIMARY KEY (site_code, booking_count_from, booking_count_to)
); 
