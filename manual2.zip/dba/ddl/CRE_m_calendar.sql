CREATE TABLE m_calendar (
year_month_date DATE PRIMARY KEY
,week_code VARCHAR(3)
,public_holiday_flag CHAR(1)
,public_holiday_name VARCHAR(20)
,weekday_flag CHAR(1)
,holiday_flag CHAR(1)
,weekday_weekday_flag CHAR(1)
,weekday_holiday_flag CHAR(1)
,holiday_weekday_flag CHAR(1)
,holiday_holiday_flag CHAR(1)
); 
