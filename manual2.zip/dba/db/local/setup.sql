-- MySQLサーバーの設定

set @character_set_server_value = 'utf8mb4';
set global character_set_server = @character_set_server_value;
set persist character_set_server = @character_set_server_value;

set @collation_server_value = 'utf8mb4_bin';
set global collation_server = @collation_server_value;
set persist collation_server = @collation_server_value;

set @transaction_isolation_value = 'READ-COMMITTED';
set global transaction_isolation = @transaction_isolation_value;
set persist transaction_isolation = @transaction_isolation_value;

set @local_infile_value = 1;
set global local_infile = @local_infile_value;
set persist local_infile = @local_infile_value;


-- データベースおよびユーザーの作成
create database booking_brain;
create user 'booking_brain_user'@'localhost' identified by 'Passw@rd';
grant alter, alter routine, create, create routine, create temporary tables, create view, delete, drop, event, execute, index, insert, lock tables, references, select, show view, trigger, update on booking_brain.* to 'booking_brain_user'@'localhost' with grant option;
grant file, show databases on *.* to 'booking_brain_user'@'localhost' with grant option;
flush privileges;


-- MySQLサーバーの再起動

restart;
