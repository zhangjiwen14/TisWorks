#!/bin/bash

RESOURCE_GROUP_NAME=rg-bookingbrain-dev-01
MYSQL_SERVER_NAME=mysql-bookingbrain-dev-01

config_set() {
  local NAME=$1
  local VALUE=$2

  az mysql server configuration set --resource-group ${RESOURCE_GROUP_NAME} --server-name ${MYSQL_SERVER_NAME} --name ${NAME} --value "${VALUE}"
}

## Character SetおよびCollation
config_set character_set_server 'utf8mb4'
config_set collation_server 'utf8mb4_bin'

## トランザクション
config_set transaction_isolation 'READ-COMMITTED'

## ローカルファイルロードの許可
config_set local_infile 'ON'

## タイムゾーン
config_set time_zone '+09:00'

## バイナリログ
### binlog_expire_logs_seconds
### binlog_row_image

## タイムアウト
config_set wait_timeout 108000

## バッファサイズ
config_set sort_buffer_size 1048576

## セキュリティ
### 監査ログ https://docs.microsoft.com/ja-jp/azure/mysql/concepts-audit-logs
# config_set audit_log_enabled 'ON'
# config_set audit_log_events 'CONNECTION,DDL,DCL,DML_NONSELECT'
