-- 先にserver configurationを行ってから実行する

create database booking_brain;
create user 'booking_brain_user'@'%' identified by 'ejKsydxfqbwV7zt1';
grant alter, alter routine, create, create routine, create temporary tables, create view, delete, drop, event, execute, index, insert, lock tables, references, select, show view, trigger, update on booking_brain.* to 'booking_brain_user'@'%' with grant option;
grant file, show databases on *.* to 'booking_brain_user'@'%' with grant option;
flush privileges;
