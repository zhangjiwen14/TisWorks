# batch

## 全体像

![application overview](temporary-docs/application-overview.png)

## 使用している主要なフレームワーク・ライブラリ

- DIコンテナ
  - [Spring Boot](https://spring.io/projects/spring-boot)
  - [Spring Framework](https://spring.io/projects/spring-framework)
- データベースアクセス
  - [Doma2](https://doma.readthedocs.io/en/latest/)

## アノテーションプロセッサーを有効にする

1. プロジェクトを右クリックして「プロパティ」
1. 「Javaコンパイラー」 → 「注釈処理」
  1. 「プロジェクト固有の設定を有効にする」にチェック
  1. 適用
1. 「Javaコンパイラー」 → 「注釈処理」 → 「ファクトリー・パス」
  1. 「プロジェクト固有の設定を有効にする」にチェック
  1. 「JARを追加」 → `annotation-processor-factory-lib`フォルダ内のJARファイル2つを追加
  1. 適用

## ローカル実行時のVM引数

```shell
-Dspring.profiles.active=local -Dbatch.id=[バッチID]
```