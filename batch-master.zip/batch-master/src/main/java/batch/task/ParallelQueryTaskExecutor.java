package batch.task;

import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import batch.framework.task.ManagedThreadPoolTaskExecutor;

public class ParallelQueryTaskExecutor extends ManagedThreadPoolTaskExecutor {
	public ParallelQueryTaskExecutor(ApplicationContext ctx, ThreadPoolTaskExecutor taskExecutor) {
		super(ctx, taskExecutor);
	}
}
