package batch;

import java.time.format.DateTimeFormatter;

import org.springframework.beans.BeansException;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.ExitCodeGenerator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.util.StringUtils;

import batch.controller.BatchController;
import batch.controller.ExitCode;
import batch.framework.logging.Logger;
import batch.logging.LogMessage;
import batch.service.BatchDateService;

@SpringBootApplication
public class Bootstrap implements CommandLineRunner, ExitCodeGenerator {
	private static final String BATCH_ID_PROPERTY_NAME_STRING = "batch.id";

	private static Logger logger = Logger.getLogger(Bootstrap.class);

	private ApplicationContext ctx;
	private BatchDateService batchDateService;
	private int exitCode;

	public Bootstrap(ApplicationContext ctx, BatchDateService batchDateService) {
		this.ctx = ctx;
		this.batchDateService = batchDateService;
	}

	public static void main(String[] args) {
		String batchId = getBatchId();

		if (!StringUtils.hasText(batchId)) {
			logger.log(LogMessage.MISSING_BATCH_ID, "-D" + BATCH_ID_PROPERTY_NAME_STRING + "=[バッチID]");
			System.exit(ExitCode.ERROR.getCode());
		}

		SpringApplication.run(Bootstrap.class, args);
	}

	static String getBatchId() {
		return System.getProperty(BATCH_ID_PROPERTY_NAME_STRING);
	}

	@Override
	public void run(String... args) throws Exception {
		String batchId = getBatchId();

		BatchController controller;

		try {
			controller = ctx.getBean(batchId, BatchController.class);
		} catch (BeansException e) {
			logger.log(LogMessage.BATCH_NOT_FOUND, batchId, e);

			exitCode = ExitCode.ERROR.getCode();

			return;
		}

		logger.log(LogMessage.BATCH_START, batchId);
		logger.log(LogMessage.CURRENT_BATCH_EXECUTION_DATE,
				batchDateService.getBatchExecutionDate().format(DateTimeFormatter.ofPattern("uuuu-MM-dd")),
				batchDateService.getSystemDateTime().format(DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss")));

		ExitCode code;

		try {
			code = controller.execute(args);
		} catch (Throwable th) {
			code = ExitCode.ERROR;

			logger.log(LogMessage.UNKNOWN_ERROR, th);
		}

		exitCode = code.getCode();

		switch (code) {
		case SUCCESS:
			logger.log(LogMessage.BATCH_SUCCESS_END, batchId, exitCode);
			break;
		case ERROR:
			logger.log(LogMessage.BATCH_ERROR_END, batchId, exitCode);
			break;
		default:
			throw new IllegalStateException("不正な終了ステータス[" + code + "]");
		}
	}

	@Override
	public int getExitCode() {
		return exitCode;
	}
}
