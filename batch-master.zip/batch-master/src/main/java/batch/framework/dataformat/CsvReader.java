package batch.framework.dataformat;

import java.io.Closeable;
import java.io.IOException;
import java.io.Reader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Iterator;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

public class CsvReader<T> implements Closeable, Iterable<T> {
	private MappingIterator<T> mappingIterator;

	public static <T> CsvReader<T> newReader(Class<T> classForSchema, String filePath) {
		try {
			return new CsvReader<>(classForSchema, Files.newBufferedReader(Paths.get(filePath), StandardCharsets.UTF_8));
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		}
	}

	protected CsvReader(Class<T> classForSchema, Reader reader) {
		CsvMapper mapper = new CsvMapper();
		CsvSchema schema = mapper
				.schemaFor(classForSchema)
				.withQuoteChar('"')
				.withEscapeChar('"')  // エスケープは " とすること
				.withColumnSeparator(',');

		try {
			mappingIterator = mapper.readerFor(classForSchema).with(schema).readValues(reader);
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		}
	}

	@Override
	public Iterator<T> iterator() {
		return mappingIterator;
	}

	@Override
	public void close() {
		try {
			mappingIterator.close();
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		}
	}
}
