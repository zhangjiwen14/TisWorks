package batch.framework.dataformat;

import java.io.Closeable;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import com.fasterxml.jackson.databind.SequenceWriter;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

public class CsvWriter<T> implements Closeable {
	private SequenceWriter sequenceWriter;

	public static <T> CsvWriter<T> newWriter(Class<T> classForSchema, String filePath) {
		try {
			return new CsvWriter<>(classForSchema,
					Files.newBufferedWriter(Paths.get(filePath), StandardCharsets.UTF_8));
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		}
	}

	protected CsvWriter(Class<T> classForSchema, Writer writer) {
		CsvMapper mapper = new CsvMapper();
		CsvSchema schema = mapper
				.schemaFor(classForSchema)
				.withColumnSeparator(',')
				.withQuoteChar('"');

		try {
			sequenceWriter = mapper.writerFor(classForSchema).with(schema).writeValues(writer);
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		}
	}

	public void write(T record) {
		try {
			sequenceWriter.write(record);
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		}
	}

	@Override
	public void close() throws IOException {
		sequenceWriter.close();
	}
}
