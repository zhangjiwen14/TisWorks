package batch.framework.task;

import java.util.concurrent.Future;
import java.util.function.Function;

import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

public class BindedTaskCaller<T> {
	private ApplicationContext ctx;
	private ThreadPoolTaskExecutor threadPoolTaskExecutor;
	private Class<T> taskClass;

	BindedTaskCaller(ApplicationContext ctx, ThreadPoolTaskExecutor threadPoolTaskExecutor, Class<T> taskClass) {
		this.threadPoolTaskExecutor = threadPoolTaskExecutor;
		this.taskClass = taskClass;

	}

	public <R> Future<R> execute(Function<T, R> function) {
		return threadPoolTaskExecutor.submit(() -> {
			T task = ctx.getBean(taskClass);
			return function.apply(task);
		});
	}
}
