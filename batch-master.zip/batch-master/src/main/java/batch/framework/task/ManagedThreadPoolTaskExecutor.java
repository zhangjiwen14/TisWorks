package batch.framework.task;

import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

public abstract class ManagedThreadPoolTaskExecutor {
	private ApplicationContext ctx;
	private ThreadPoolTaskExecutor taskExecutor;

	public ManagedThreadPoolTaskExecutor(ApplicationContext ctx, ThreadPoolTaskExecutor taskExecutor) {
		this.ctx = ctx;
		this.taskExecutor = taskExecutor;
	}

	public <T> BindedTaskCaller<T> bindTaskClass(Class<T> taskClass) {
		return new BindedTaskCaller<T>(ctx, taskExecutor, taskClass);
	}
}
