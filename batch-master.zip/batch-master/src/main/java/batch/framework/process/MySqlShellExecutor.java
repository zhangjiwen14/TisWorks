package batch.framework.process;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import org.springframework.stereotype.Component;
import org.zeroturnaround.exec.InvalidExitValueException;
import org.zeroturnaround.exec.ProcessExecutor;
import org.zeroturnaround.exec.ProcessResult;
import org.zeroturnaround.exec.stream.LogOutputStream;

import batch.framework.exception.SystemRuntimeException;
import batch.framework.logging.Logger;
import batch.logging.LogMessage;

@Component
public class MySqlShellExecutor {
	private Logger logger = Logger.getLogger(MySqlShellExecutor.class);

	public ImportTableResult importTable(String tableName, String importFilePath) {
		final ImportTableResult importTableResult = new ImportTableResult();
		
		try {
			ProcessResult result = new ProcessExecutor()
					.command(
							"mysqlsh",
							"-u",
							"-p",
							"--",
							"import_table",
							importFilePath,
							"--schema",
							"--table",
							tableName,
							"--replaceDuplicates",
							"true",
							"--fieldsTerminatedBy",
							",",
							"--fieldsEnclosedBy",
							"'\"'",
							"--fieldsOptionallyEnclosed",
							"true",
							"--fieldsEscapedBy",
							"'\"'",
							"--showProgress",
							"false"
							)
					.redirectOutput(new LogOutputStream() {
						@Override
						protected void processLine(String line) {
							logger.log(LogMessage.EXTERNAL_COMMAND_EXECUTION_LOG, line);
						}
					})
					.execute();
			
			int exitValue =  result.getExitValue();
			
			importTableResult.setSuccess(exitValue == 0);
		} catch (InvalidExitValueException | IOException | InterruptedException | TimeoutException e) {
			throw new SystemRuntimeException(e);
		}
		
		
		return importTableResult;
	}
	
	public static class ImportTableResult {
		private boolean sucess;

		private int records;
		private int deleted;
		private int skipped;
		private int warnings;

		ImportTableResult setSuccess(boolean success) {
			this.sucess = success;
			return this;
		}

		ImportTableResult addRecords(int records) {
			this.records += records;
			return this;
		}

		ImportTableResult addDeleted(int deleted) {
			this.deleted += deleted;
			return this;
		}

		ImportTableResult addSkipped(int skipped) {
			this.skipped = skipped;
			return this;
		}

		ImportTableResult addWarnings(int warnings) {
			this.warnings = warnings;
			return this;
		}

		public boolean isSuccess() {
			return sucess;
		}

		public int getRecords() {
			return records;
		}

		public int getDeleted() {
			return deleted;
		}

		public int getSkipped() {
			return skipped;
		}

		public int getWarnings() {
			return warnings;
		}
	}
}
