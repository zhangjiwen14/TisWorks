package batch.framework.logging;

public interface LogId {
	String getId();
	LogLevel getLogLevel();
}
