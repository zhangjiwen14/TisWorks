package batch.framework.logging;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

import org.slf4j.LoggerFactory;

public class Logger {
	private org.slf4j.Logger underlyingLogger;
	
	private static Properties messages;
	
	static {
		messages = new Properties();
		
		try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("logging-messages.properties");
				InputStreamReader isr = new InputStreamReader(is, StandardCharsets.UTF_8);
				BufferedReader reader =  new BufferedReader(isr)) {
			messages.load(reader);
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		}
	}
	
	
	public static Logger getLogger(Class<?> clazz) {
		return new Logger(clazz);
	}
	
	protected Logger(Class<?> clazz) {
		underlyingLogger = LoggerFactory.getLogger(clazz);
	}
	
	public void log(LogId logId, Object... args) {
		LogLevel level = logId.getLogLevel();
		
		String messageFormat = messages.getProperty(logId.getId());
		
		switch (level) {
		case DEBUG:
			underlyingLogger.debug(messageFormat, args);
			break;
		case INFO:
			underlyingLogger.info(messageFormat, args);
			break;
		case WARNINNG:
			underlyingLogger.warn(messageFormat, args);
			break;
		case ERROR:
			underlyingLogger.error(messageFormat, args);
			break;
		}
	}
}
