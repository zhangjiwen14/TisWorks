package batch.framework.logging;

public enum LogLevel {
	DEBUG, INFO, WARNINNG, ERROR
}
