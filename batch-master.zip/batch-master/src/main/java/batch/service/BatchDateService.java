package batch.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class BatchDateService {
	private static final String BATCH_EXECUTION_DATE_PROPERTY_NAME = "batch.execution.date";

	private LocalDate batchExecutionDate;
	private LocalDateTime systemDateTime;

	@PostConstruct
	void init() {
		String batchExecutionDateAsString = System.getProperty(BATCH_EXECUTION_DATE_PROPERTY_NAME);

		if (StringUtils.hasText(batchExecutionDateAsString)) {
			batchExecutionDate = LocalDate.parse(batchExecutionDateAsString, DateTimeFormatter.ofPattern("uuuu-MM-dd"));
		} else {
			batchExecutionDate = LocalDate.now();
		}
		
		systemDateTime = LocalDateTime.now();
	}

	public LocalDate getBatchExecutionDate() {
		return batchExecutionDate;
	}

	public LocalDateTime getSystemDateTime() {
		return systemDateTime;
	}
}
