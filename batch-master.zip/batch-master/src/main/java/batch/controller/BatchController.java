package batch.controller;

public interface BatchController {
	ExitCode execute(String[] args);
}
