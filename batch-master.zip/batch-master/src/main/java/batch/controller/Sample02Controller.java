package batch.controller;

import batch.framework.annotation.BatchId;

@BatchId("sample02")
public class Sample02Controller implements BatchController {

	@Override
	public ExitCode execute(String[] args) {
		return ExitCode.SUCCESS;
	}

}
