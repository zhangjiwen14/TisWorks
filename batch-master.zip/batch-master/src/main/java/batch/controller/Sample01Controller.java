package batch.controller;

import batch.framework.annotation.BatchId;

@BatchId("sample01")
public class Sample01Controller implements BatchController {
	@Override
	public ExitCode execute(String[] args) {
		return ExitCode.SUCCESS;
	}
}
