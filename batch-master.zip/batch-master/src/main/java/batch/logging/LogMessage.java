package batch.logging;

import batch.framework.logging.LogId;
import batch.framework.logging.LogLevel;

public enum LogMessage implements LogId {
	// for Application
	
	// for Framework
	BATCH_START("LOG-10000", LogLevel.INFO),
	BATCH_SUCCESS_END("LOG-10001", LogLevel.INFO),
	BATCH_ERROR_END("LOG-10002", LogLevel.INFO),
	MISSING_BATCH_ID("LOG-10003", LogLevel.ERROR),
	EXTERNAL_COMMAND_EXECUTION_LOG("LOG-10004", LogLevel.INFO),
	BATCH_NOT_FOUND("LOG-10005", LogLevel.ERROR),
	CURRENT_BATCH_EXECUTION_DATE("LOG-10006", LogLevel.INFO),
	UNKNOWN_ERROR("LOG-19999", LogLevel.ERROR);

	private String id;
	private LogLevel level;

	private LogMessage(String id, LogLevel level) {
		this.id = id;
		this.level = level;
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public LogLevel getLogLevel() {
		return level;
	}
}
